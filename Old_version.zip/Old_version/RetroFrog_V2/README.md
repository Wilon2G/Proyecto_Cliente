# Idea: Pagina web de compra de videojuegos retro

## Lista de juegos: 
Tic-tac-toe,
Tetris,
Space invaders,
Cuatro en raya,
Súper amigo italiano,
Mario kart,
Cookie cliker,
Trivia,
Piedra Papel Tijeras,
ant smasher,
Flappy bird,
noodle jump,
minecraft,
dokey-kong
## Lista de consolas:
Nintendo: nes, snes, n64, gamecube
Playstation: psx.
Sega: Megadrive.


# Clicker
https://github.com/AlejandroGonzalezNavarro/Clicker_Aldea
## Paleta  
https://lospec.com/palette-list/jehkoba64

===================
https://wilon2g.github.io/Proyecto_Cliente/
