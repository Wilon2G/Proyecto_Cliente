
export default function HomeFooter(){
    return <footer>
<<<<<<< HEAD:RetroFrog V3/src/components/HomeFooter.tsx
        <h1>¡Gracias por visitar RetrFrog!</h1>
=======
        <h1>¡Gracias por visitar RetroFrog!</h1>
>>>>>>> origin/feature-gui:RetroFrog V3/src/pages/HomeComponents/HomeFooter.tsx
        <div>
            <h3>Contacta con nosotros</h3>
            <ul>
                <li>Phone: +34 916036188</li>
                <li>¿Cómo podemos ayudarte?</li>
                <li>¡No te pierdas lo último, activa nuestro newsletter!</li>
            </ul>
        </div>
        <div>
        <h3>Nuestras redes</h3>
            <ul>
                <li><img src="/src/assets/icons/X.png"></img></li>
                <li>¿Cómo podemos ayudarte?</li>
                <li>¡No te pierdas lo último, activa nuestro newsletter!</li>
            </ul>
        </div>
        <div>
        <h3>Contacta con nosotros</h3>
            <ul>
                <li>Phone: +34 916036188</li>
                <li>¿Cómo podemos ayudarte?</li>
                <li>¡No te pierdas lo último, activa nuestro newsletter!</li>
            </ul>
        </div>
    </footer>
}

{/* <a target="_blank" href="https://icons8.com/icon/YfCbGWCWcuar/twitterx">X</a> icono de <a target="_blank" href="https://icons8.com">Icons8</a> */}