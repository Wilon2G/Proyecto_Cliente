
export default  function BomberMan(){
return <iframe  src="https://www.retrogames.cc/embed/17398-super-bomberman-usa.html" allowFullScreen />

}