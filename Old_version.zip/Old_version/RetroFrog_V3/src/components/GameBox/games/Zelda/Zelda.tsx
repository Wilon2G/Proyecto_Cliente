
export default  function Zelda(){
return <iframe  src="https://www.retrogames.cc/embed/44785-the-legend-of-zelda-a-link-to-the-past-title-skip-and-full-hearts.html" allowFullScreen />

}

