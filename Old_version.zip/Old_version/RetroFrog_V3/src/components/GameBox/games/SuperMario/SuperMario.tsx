
export default  function BomberMan(){
return <iframe  src="https://www.retrogames.cc/embed/44282-super-mario-world-u-prototype.html" allowFullScreen />

}