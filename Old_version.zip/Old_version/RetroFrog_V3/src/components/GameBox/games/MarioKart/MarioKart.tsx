

export default  function BomberMan(){
return <iframe  src="https://www.retrogames.cc/embed/43860-super-mario-kart-deluxe.html" allowFullScreen />

}