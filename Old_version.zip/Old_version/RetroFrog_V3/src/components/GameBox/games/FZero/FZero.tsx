

export default  function FZero(){
return <iframe src="https://www.retrogames.cc/embed/20082-f-zero-usa.html" allowFullScreen />

}

