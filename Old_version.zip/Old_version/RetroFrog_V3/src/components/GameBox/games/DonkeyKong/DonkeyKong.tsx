
export default  function DonkeyKong(){
return <iframe  src="https://www.retrogames.cc/embed/23005-donkey-kong-country-usa.html" allowFullScreen />

}

