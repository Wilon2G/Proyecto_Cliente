

export default  function StreetFighter(){
return <iframe  src="https://www.retrogames.cc/embed/23550-super-street-fighter-ii-the-new-challengers-usa.html" allowFullScreen />

}
